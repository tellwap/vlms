<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Center extends Model
{
    use HasFactory;
    protected $fillable = ['district_id','name','location_id'];

    public function district(){
        return $this->belongsTo(District::class);
    }
    public function location(){
        return $this->belongsTo(Location::class);
    }
}
