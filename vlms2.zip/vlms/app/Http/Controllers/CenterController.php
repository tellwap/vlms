<?php

namespace App\Http\Controllers;

use App\Models\Center;
use App\Models\Location;
use Illuminate\Http\Request;

class CenterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Center::with('location')->get();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'district_id'=>'required',
            'name'=>'required',
            'latitude'=>'required',
            'longitude'=>'required'

        ]);
        //create first location
        $location = Location::create($request->all());

        $center =  Center::create([
            'district_id'=>$request->district_id,
            'name'=>$request->name,
            'location_id'=>$location->id
        ]);
        return $center->load('location');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Center::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'district_id'=>'required',
            'name'=>'required',
            'latitude'=>'required',
            'longitude'=>'required'

        ]);
        $center = Center::find($id);
        $center->update($request->all());
        return $center;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return Center::destroy($id);
    }

    /**
     * Search for a center.
     *
     * @param  str  $name
     * @return \Illuminate\Http\Response
     */
    public function search($name)
    {
        //return Center::where('name',$name)->get();
        return Center::where('name','like','%'.$name.'%')->get();

    }
}
